<?php
// DO NOT DELETE
// This file is for testing read/write permissions on this directory!