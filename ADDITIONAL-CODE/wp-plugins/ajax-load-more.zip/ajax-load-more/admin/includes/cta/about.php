<div class="cta">
	<h3>Other Projects</h3>
	<ul>
		<li><strong><a target="blank" href="https://connekthq.com/plugins/easy-query/">Easy Query</a></strong><br>A simple solution to build and display WordPress queries without touching a single line of code.</li>
		<li><strong><a target="blank" href="https://connekthq.com/plugins/velocity/">Velocity</a></strong><br>Improve website performance by lazy loading and customizing your embedded media with Velocity.</li>
		<li><strong><a target="blank" href="https://connekthq.com/plugins/unsplash-wp/">Unsplash WP</a></strong><br>The fastest way to upload high quality stock photos from unsplash.com directly to your media library.</li>
		<li><strong><a target="blank" href="https://github.com/dcooney/flexpanel">FlexPanel</a></strong><br>A responsive scrolling panel navigation for mobile and desktop.</li>
		<li><strong><a target="blank" href="https://connekthq.com">Connekt Media</a></strong><br>A digital creation company.</li>
	</ul>	
</div>

