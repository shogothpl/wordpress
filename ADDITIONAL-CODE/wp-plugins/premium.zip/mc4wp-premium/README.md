### MailChimp for WordPress - Premium Bundle

This plugin contains all [premium features](https://mc4wp.com/features/) for [MailChimp for WordPress](https://mc4wp.com/).

- AJAX Forms
- Multiple Forms
- Custom Color Form Theme
- Logging
- Statistics
- Email Notifications
- E-Commerce

Not sure how to install this plugin? Please have a look at the [installation guide](https://mc4wp.com/kb/installation-instructions/).

More help articles can be found in [our knowledge base](https://mc4wp.com/kb/) or in our [code reference](http://developer.mc4wp.com/) for developers.

Enjoy!

Danny, Ines & Harish
[mc4wp.com](https://mc4wp.com)

MailChimp for WordPress is a product by [ibericode](https://ibericode.com/)