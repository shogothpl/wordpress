### MailChimp for WordPress - Custom Color Form Theme

This add-on plugin adds a custom colored form theme option to MailChimp for WordPress.