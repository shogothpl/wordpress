### MailChimp for WordPress - Multiple Forms

This add-on plugin for [MailChimp for WordPress](https://mc4wp.com/) enables you to create more than one sign-up form.